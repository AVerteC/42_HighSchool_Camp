#!/usr/bin/ruby

input = ARGV
if input.count == 2
	times = input[1].scan(input[0])
	puts times.count
else
	puts "none"
end
