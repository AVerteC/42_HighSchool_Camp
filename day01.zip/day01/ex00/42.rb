#!/usr/bin/ruby
puts "42"
