#!/usr/bin/ruby
print "What's your first name ? : "
first_name = gets.chomp
print "What's your last name ? : "
last_name = gets.chomp
puts "Well, pleased to meet you, #{first_name} #{last_name}"
