#!/usr/bin/ruby

input = ARGV
if input == []
	puts "none"
else
	puts input[0].upcase
end
