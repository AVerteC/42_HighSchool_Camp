#!/usr/bin/ruby
first_name = "Arthur"
last_name = "Dent"
puts "#{first_name} #{last_name}"
