#!/usr/bin/ruby
input_array = []
input_array = ARGV
if input_array == []
	puts "none"
else
	puts input_array[0]
end
