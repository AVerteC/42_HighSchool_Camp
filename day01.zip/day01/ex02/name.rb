#!/usr/bin/ruby

first_name = "Ford"
last_name = "Prefect"
full_name = "#{first_name} #{last_name}"
puts full_name
