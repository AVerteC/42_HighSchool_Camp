#!/usr/bin/ruby
print "Please tell me your age : "
cur_age = gets.chomp.to_i
tenyrs = cur_age + 10
twentyyrs = cur_age + 20
thirtyyrs = cur_age + 30
puts "You are currently #{cur_age} years old."
puts "In 10 years, you'll be #{tenyrs} years old."
puts "In 20 years, you'll be #{twentyyrs} years old."
puts "in 30 years, you'll be #{thirtyyrs} years old."
